package br.com.estudos.biblioteca.model;

import javax.annotation.processing.Generated;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "livros")
@Getter
@Setter
@NoArgsConstructor

public class Livro{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O título é obrigatório")
    @Size(min = 2, max = 100, 
          message = "O título deve ter entre 2 e 100 caracteres")
    private String titulo;

    @NotBlank(message = "O autor é obrigatório")
    @Size(min = 2, max = 80,
        message = "O autor deve ter entre 2 e 80 caracteres")
    private String autor;

    @NotBlank(message = "O ISBN é obrigatório")
    @Column(unique = true, nullable= false)
    private String isbn;

    @NotNull(message ="O ano é obrigatório")
    @Min(value = 1450, message = "O ano deve ser igual ou posterior a 1450")
    @Max(value = 2100, message = "O ano informado é inválido")
    private Integer anoPublicacao;
}