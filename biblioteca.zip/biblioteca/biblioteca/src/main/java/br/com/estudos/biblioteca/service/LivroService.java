package br.com.estudos.biblioteca.service;

import br.com.estudos.biblioteca.model.Livro;
import br.com.estudos.biblioteca.repository.LivroRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LivroService{
    private final LivroRepository repository;

    public LivroService(LivroRepository repository){
        this.repository = repository;
    }

    public List<Livro> listarTodos(){
        return repository.findAll();
    }

    public Optional<Livro> buscarPorId(Long id)
}