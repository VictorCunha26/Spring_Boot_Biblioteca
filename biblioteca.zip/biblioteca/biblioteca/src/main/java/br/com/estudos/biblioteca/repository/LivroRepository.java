package br.com.estudos.repository;

import br.com.estudos.biblioteca.model.Livro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepository
    extends JpaRepository<Livro, Long>{
        boolean existsByIsbn(String isbn);
    }